# Projekt - Plantie

Opis -> Naša aplikacija služi da vam pomogne u nabavljanju i održavanju bilja
Članovi -> Danijela Mudrić, Monia Kopjar, Nika Smuđ, Emma Šafar
